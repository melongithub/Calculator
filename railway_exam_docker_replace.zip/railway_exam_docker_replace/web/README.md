# 铁路线路工安全题库 H5

一个纯静态、手机优先的 H5 考试练习应用。题库已从 `1.安全（铁路线路工）.xlsx` 转换并内置，共 70 题。

## 已实现功能

- 顺序练习
- 随机练习
- 专项练习（单选 / 多选 / 判断 / 填空 / 简答）
- 模拟考试（60 道客观题、60 分钟、自动判分）
- 错题本（答错自动加入，后续答对自动移除）
- 收藏夹
- 考试记录
- 答题设置
- 多选整组判分
- 有序 / 无序填空判分
- 简答题参考答案 + 自评
- 本地保存学习进度
- PWA 离线缓存

## 最简单部署方式

把整个 `rail_exam_h5` 目录复制到电视盒子服务器，然后在目录内启动静态 HTTP 服务：

```bash
cd rail_exam_h5
python3 -m http.server 8080 --bind 0.0.0.0
```

手机浏览器访问：

```text
http://电视盒子IP:8080/
```

例如电视盒子 IP 是 `192.168.1.50`：

```text
http://192.168.1.50:8080/
```

> 不建议直接双击 `index.html` 使用。通过 HTTP/HTTPS 访问时，离线缓存和 PWA 功能才完整。

## Nginx 部署

将本目录内容放到 Nginx 站点目录即可。示例：

```nginx
server {
    listen 8080;
    server_name _;
    root /var/www/rail_exam_h5;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location ~* \.(js|css|svg|json)$ {
        expires 7d;
        add_header Cache-Control "public";
    }
}
```

## 数据保存位置

练习进度、错题、收藏、考试记录保存在手机浏览器 `localStorage` 中；正在进行的答题会话保存在 `sessionStorage` 中。

这意味着：

- 不需要数据库
- 不需要后端接口
- 不同手机的数据彼此独立
- 清除浏览器网站数据会同时清除学习记录

## 目录说明

```text
rail_exam_h5/
├── index.html
├── styles.css
├── app.js
├── manifest.json
├── sw.js
├── icon.svg
├── README.md
└── data/
    ├── questions.js
    └── questions.json
```

`data/questions.json` 便于后续检查或二次开发；实际页面默认加载 `data/questions.js`。
