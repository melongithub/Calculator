(() => {
  'use strict';

  const BANK = Array.isArray(window.QUESTION_BANK) ? window.QUESTION_BANK : [];
  const APP = document.getElementById('app');
  const TOAST = document.getElementById('toast');
  const STORAGE_KEY = 'rail_exam_h5_state_v1';
  const SESSION_KEY = 'rail_exam_h5_session_v1';

  const TYPE_INFO = {
    single:   { name: '单项选择题', icon: '🔘', desc: '每题只有一个正确答案' },
    multiple: { name: '多项选择题', icon: '☑️', desc: '全部选对才算正确' },
    judge:    { name: '判断题', icon: '⚖️', desc: '判断题干说法正误' },
    fill:     { name: '填空题', icon: '✍️', desc: '按题意填写关键词' },
    short:    { name: '简答题', icon: '📝', desc: '查看参考答案后自评' }
  };

  let state = loadState();
  let session = loadSession();
  let timerHandle = null;

  function defaultState() {
    return {
      practiced: {},
      wrongIds: [],
      favoriteIds: [],
      records: [],
      settings: { autoNext: false }
    };
  }

  function loadState() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      return Object.assign(defaultState(), parsed || {}, {
        settings: Object.assign(defaultState().settings, parsed?.settings || {})
      });
    } catch (_) {
      return defaultState();
    }
  }

  function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  function loadSession() {
    try {
      return JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null');
    } catch (_) {
      return null;
    }
  }

  function saveSession() {
    if (session) sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
    else sessionStorage.removeItem(SESSION_KEY);
  }

  function qById(id) {
    return BANK.find(q => Number(q.id) === Number(id));
  }

  function esc(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function showToast(message, ms = 1600) {
    TOAST.textContent = message;
    TOAST.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => TOAST.classList.remove('show'), ms);
  }

  function shuffle(arr) {
    const out = [...arr];
    for (let i = out.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
  }

  function routeTo(hash) {
    if (location.hash === hash) renderRoute();
    else location.hash = hash;
  }

  function parseRoute() {
    const raw = location.hash.replace(/^#/, '') || 'home';
    const [path, query = ''] = raw.split('?');
    return { path, params: new URLSearchParams(query) };
  }

  function topbar(title, { back = true, right = '' } = {}) {
    return `
      <header class="topbar">
        <div class="topbar-inner">
          ${back ? '<button class="icon-btn" data-action="back" aria-label="返回">‹</button>' : '<span></span>'}
          <div class="topbar-title">${esc(title)}</div>
          ${right || '<span></span>'}
        </div>
      </header>`;
  }

  function getPracticedCount() {
    return Object.keys(state.practiced || {}).length;
  }

  function typeProgress(type) {
    const qs = BANK.filter(q => q.type === type);
    const done = qs.filter(q => state.practiced[q.id]).length;
    return { done, total: qs.length };
  }

  function renderHome() {
    stopTimer();
    const total = BANK.length;
    const done = getPracticedCount();
    const percent = total ? Math.round(done / total * 100) : 0;
    APP.innerHTML = `
      <main class="page">
        <section class="home-header">
          <div class="container">
            <div class="brand-row">
              <div class="brand-logo">🚆</div>
              <div>
                <div class="brand-title">铁路线路工安全题库</div>
                <div class="brand-subtitle">安全知识专项学习 · 共 ${total} 题</div>
              </div>
            </div>
            <div class="header-progress">
              <div class="progress-label"><span>总体练习进度</span><strong>${percent}%</strong></div>
              <div class="progress-track"><div class="progress-fill" style="width:${percent}%"></div></div>
            </div>
          </div>
        </section>

        <div class="container home-main">
          <section class="stats-card" aria-label="学习统计">
            <div class="stat"><div class="stat-num">${total}</div><div class="stat-label">题库总数</div></div>
            <div class="stat"><div class="stat-num">${done}</div><div class="stat-label">已练习</div></div>
            <div class="stat"><div class="stat-num">${state.wrongIds.length}</div><div class="stat-label">错题</div></div>
            <div class="stat"><div class="stat-num">${state.favoriteIds.length}</div><div class="stat-label">收藏</div></div>
          </section>

          <h2 class="section-title">开始学习</h2>
          <section class="module-grid">
            ${moduleCard('sequence', 'm-blue', '📚', '顺序练习', '按题库顺序逐题练习')}
            ${moduleCard('random', 'm-green', '🔀', '随机练习', '打乱全部题目顺序')}
            ${moduleCard('special', 'm-orange', '🎯', '专项练习', '按题型分类强化训练')}
            ${moduleCard('exam', 'm-purple', '⏱️', '模拟考试', '60道客观题 · 60分钟')}
            ${moduleCard('wrong', 'm-red', '❌', '错题本', `${state.wrongIds.length} 道待巩固题目`)}
            ${moduleCard('favorite', 'm-yellow', '⭐', '收藏夹', `${state.favoriteIds.length} 道已收藏题目`)}
            ${moduleCard('records', 'm-cyan', '📊', '考试记录', `${state.records.length} 次模拟考试记录`)}
            ${moduleCard('settings', 'm-gray', '⚙️', '答题设置', '自动跳题与数据管理')}
          </section>

          <div class="info-strip">题库来源：1.安全（铁路线路工）.xlsx。学习进度、错题、收藏和考试记录均保存在当前手机浏览器本机。</div>
        </div>
      </main>`;
  }

  function moduleCard(action, cls, icon, name, desc) {
    return `<button class="module-card ${cls}" data-home-action="${action}">
      <div class="module-icon">${icon}</div>
      <div class="module-name">${esc(name)}</div>
      <div class="module-desc">${esc(desc)}</div>
    </button>`;
  }

  function renderSpecial() {
    stopTimer();
    APP.innerHTML = `
      <main class="page">
        ${topbar('专项练习')}
        <div class="container list-page">
          <div class="list-card">
            ${Object.entries(TYPE_INFO).map(([type, info]) => {
              const p = typeProgress(type);
              return `<button class="list-item" data-type="${type}">
                <div class="list-icon">${info.icon}</div>
                <div class="list-main">
                  <div class="list-title">${info.name}</div>
                  <div class="list-meta">${info.desc} · ${p.done}/${p.total} 已练习</div>
                </div>
                <div class="list-arrow">›</div>
              </button>`;
            }).join('')}
          </div>
        </div>
      </main>`;
  }

  function renderRecords() {
    stopTimer();
    const records = [...state.records].reverse();
    APP.innerHTML = `
      <main class="page">
        ${topbar('考试记录')}
        <div class="container list-page">
          ${records.length ? `
            <div class="record-list">
              ${records.map(r => `<article class="record-card">
                <div class="record-top">
                  <div><span class="record-score">${esc(r.score)}</span><span class="small-muted"> 分</span></div>
                  <span class="record-tag">模拟考试</span>
                </div>
                <div class="record-meta">${esc(r.date)}<br>答对 ${esc(r.correct)} / ${esc(r.total)} 题 · 用时 ${formatDuration(r.duration)}</div>
              </article>`).join('')}
            </div>
            <button class="danger-btn mt-18" style="width:100%" data-action="clear-records">清空考试记录</button>
          ` : emptyState('📊', '暂无考试记录', '完成一次模拟考试后，成绩会自动保存在这里。', '开始模拟考试', 'start-exam')}
        </div>
      </main>`;
  }

  function renderSettings() {
    stopTimer();
    APP.innerHTML = `
      <main class="page">
        ${topbar('答题设置')}
        <div class="container list-page">
          <div class="settings-card">
            <div class="setting-row">
              <div><div class="setting-title">答对后自动下一题</div><div class="setting-desc">练习模式答对后约 0.6 秒自动跳转</div></div>
              <button class="switch ${state.settings.autoNext ? 'on' : ''}" data-action="toggle-auto" aria-label="切换自动下一题"></button>
            </div>
          </div>
          <h2 class="section-title">学习数据</h2>
          <div class="settings-card">
            <div class="setting-row">
              <div><div class="setting-title">当前学习记录</div><div class="setting-desc">已练习 ${getPracticedCount()} 题，错题 ${state.wrongIds.length} 题，收藏 ${state.favoriteIds.length} 题</div></div>
            </div>
          </div>
          <button class="danger-btn mt-18" style="width:100%" data-action="reset-data">清空全部学习数据</button>
        </div>
      </main>`;
  }

  function emptyState(icon, title, desc, btnText = '', action = '') {
    return `<div class="list-card empty-state">
      <div class="empty-icon">${icon}</div>
      <div class="empty-title">${esc(title)}</div>
      <div class="empty-desc">${esc(desc)}</div>
      ${btnText ? `<button class="primary-btn" data-action="${action}">${esc(btnText)}</button>` : ''}
    </div>`;
  }

  function startPractice(mode, options = {}) {
    let qs = [];
    let title = '练习';

    if (mode === 'sequence') {
      qs = [...BANK]; title = '顺序练习';
    } else if (mode === 'random') {
      qs = shuffle(BANK); title = '随机练习';
    } else if (mode === 'type') {
      qs = BANK.filter(q => q.type === options.type); title = TYPE_INFO[options.type]?.name || '专项练习';
    } else if (mode === 'wrong') {
      qs = state.wrongIds.map(qById).filter(Boolean); title = '错题本';
    } else if (mode === 'favorite') {
      qs = state.favoriteIds.map(qById).filter(Boolean); title = '收藏夹';
    } else if (mode === 'custom') {
      qs = (options.ids || []).map(qById).filter(Boolean); title = options.title || '专项练习';
    }

    if (!qs.length) {
      showToast(mode === 'wrong' ? '错题本还是空的' : mode === 'favorite' ? '收藏夹还是空的' : '暂无可练习题目');
      return;
    }

    session = {
      mode, title,
      ids: qs.map(q => q.id),
      index: 0,
      answers: {},
      results: {},
      startedAt: Date.now(),
      isExam: false,
      submitted: false
    };
    saveSession();
    routeTo('#quiz');
  }

  function startExam() {
    const objective = BANK.filter(q => ['single', 'multiple', 'judge'].includes(q.type));
    session = {
      mode: 'exam', title: '模拟考试', ids: shuffle(objective).map(q => q.id), index: 0,
      answers: {}, results: {}, startedAt: Date.now(), isExam: true,
      durationSec: 60 * 60, submitted: false
    };
    saveSession();
    routeTo('#quiz');
  }

  function currentQuestion() {
    return session ? qById(session.ids[session.index]) : null;
  }

  function renderQuiz() {
    if (!session || !session.ids?.length) {
      routeTo('#home');
      return;
    }
    if (session.submitted && session.examResult) {
      renderExamResult();
      return;
    }

    const q = currentQuestion();
    if (!q) { routeTo('#home'); return; }
    const total = session.ids.length;
    const idx = session.index;
    const answer = session.answers[q.id];
    const result = session.results[q.id];
    const fav = state.favoriteIds.includes(q.id);
    const pct = Math.round((idx + 1) / total * 100);

    APP.innerHTML = `
      <main class="page question-page">
        ${topbar(session.title, { right: '<button class="icon-btn" data-action="navigator" aria-label="答题卡">▦</button>' })}
        ${session.isExam ? `<div class="exam-banner">剩余时间 <strong id="examTimer">${formatRemaining(getRemainingSec())}</strong> · 已答 ${Object.keys(session.answers).filter(k => hasAnswer(session.answers[k])).length}/${total}</div>` : ''}
        <section class="q-progress container">
          <div class="q-progress-row"><span>第 ${idx + 1} / ${total} 题</span><span>${pct}%</span></div>
          <div class="q-progress-track"><div class="q-progress-fill" style="width:${pct}%"></div></div>
        </section>
        <div class="container question-wrap">
          <article class="question-card">
            <div class="q-meta">
              <span class="type-tag">${esc(q.typeName)}</span>
              <span class="q-number">题库编号 ${q.id}</span>
              <button class="favorite-btn ${fav ? 'active' : ''}" data-action="favorite" aria-label="收藏">${fav ? '★' : '☆'}</button>
            </div>
            <div class="question-text">${esc(q.question)}</div>
            ${renderAnswerInput(q, answer, result)}
            ${!session.isExam && result ? renderAnswerPanel(q, result) : ''}
          </article>
        </div>
        <nav class="bottom-actions">
          <div class="bottom-actions-inner">
            <button class="bottom-btn prev" data-action="prev" ${idx === 0 ? 'disabled' : ''}>上一题</button>
            <button class="bottom-btn main" data-action="main">${mainButtonText(q, result)}</button>
            <button class="bottom-btn next" data-action="next" ${idx === total - 1 ? 'disabled' : ''}>下一题</button>
          </div>
        </nav>
      </main>`;

    if (session.isExam) startTimer(); else stopTimer();
  }

  function renderAnswerInput(q, answer, result) {
    const locked = !session.isExam && !!result;
    if (q.type === 'single' || q.type === 'multiple') {
      const selected = q.type === 'multiple' ? new Set(String(answer || '').split('')) : new Set(answer ? [String(answer)] : []);
      return `<div class="option-list">${Object.entries(q.options || {}).map(([key, text]) => {
        const cls = optionClass(q, key, selected.has(key), result);
        const mark = optionMark(q, key, selected.has(key), result);
        return `<button class="option ${cls}" data-option="${esc(key)}" ${locked ? 'disabled' : ''}>
          <span class="option-key">${esc(key)}</span><span class="option-text">${esc(text)}</span><span class="option-mark">${mark}</span>
        </button>`;
      }).join('')}</div>`;
    }

    if (q.type === 'judge') {
      const selected = new Set(answer ? [String(answer)] : []);
      return `<div class="option-list">${['正确','错误'].map(key => {
        const cls = optionClass(q, key, selected.has(key), result);
        const mark = optionMark(q, key, selected.has(key), result);
        return `<button class="option ${cls}" data-option="${key}" ${locked ? 'disabled' : ''}>
          <span class="option-key">${key === '正确' ? '✓' : '✕'}</span><span class="option-text">${key}</span><span class="option-mark">${mark}</span>
        </button>`;
      }).join('')}</div>`;
    }

    if (q.type === 'fill') {
      return `<input class="answer-input" id="textAnswer" type="text" value="${esc(answer || '')}" placeholder="请输入答案，多空可用逗号分隔" ${locked ? 'disabled' : ''} autocomplete="off" />
        <div class="fill-hint">${esc(q.fillType || '填空题')}：多空答案可用“，”“、”或“；”分隔</div>`;
    }

    return `<textarea class="answer-input" id="textAnswer" placeholder="请先作答，再查看参考答案" ${locked ? 'disabled' : ''}>${esc(answer || '')}</textarea>`;
  }

  function optionClass(q, key, selected, result) {
    if (session.isExam || !result) return selected ? 'selected' : '';
    const correctSet = new Set(q.type === 'multiple' ? String(q.answer).split('') : [String(q.answer)]);
    if (correctSet.has(key)) return 'correct';
    if (selected && !correctSet.has(key)) return 'wrong';
    return '';
  }

  function optionMark(q, key, selected, result) {
    if (session.isExam || !result) return '';
    const correctSet = new Set(q.type === 'multiple' ? String(q.answer).split('') : [String(q.answer)]);
    if (correctSet.has(key)) return '✓';
    if (selected && !correctSet.has(key)) return '✕';
    return '';
  }

  function renderAnswerPanel(q, result) {
    if (q.type === 'short') {
      const rated = result === 'self-correct' || result === 'self-wrong';
      return `<section class="answer-panel">
        <div class="answer-head neutral">📘 参考答案</div>
        <div class="answer-body">
          <div class="answer-line">${esc(q.answer || '暂无参考答案')}</div>
          ${q.analysis ? `<div class="answer-line"><span class="answer-label">解析/出处</span>${esc(q.analysis)}</div>` : ''}
          ${!rated ? `<div class="self-rate"><button class="rate-good" data-action="self-rate" data-rate="good">✓ 我已掌握</button><button class="rate-bad" data-action="self-rate" data-rate="bad">✕ 还需巩固</button></div>` : `<div class="answer-line"><span class="answer-label">自评结果</span>${result === 'self-correct' ? '已掌握' : '还需巩固'}</div>`}
        </div>
      </section>`;
    }

    const good = result === true;
    return `<section class="answer-panel">
      <div class="answer-head ${good ? 'good' : 'bad'}">${good ? '✓ 回答正确' : '✕ 回答错误'}</div>
      <div class="answer-body">
        <div class="answer-line"><span class="answer-label">正确答案</span><strong>${esc(displayAnswer(q))}</strong></div>
        ${q.analysis ? `<div class="answer-line"><span class="answer-label">解析/出处</span>${esc(q.analysis)}</div>` : ''}
      </div>
    </section>`;
  }

  function displayAnswer(q) {
    if ((q.type === 'single' || q.type === 'multiple') && q.options) {
      return String(q.answer).split('').map(k => `${k}. ${q.options[k] || ''}`).join('；');
    }
    return q.answer || '';
  }

  function mainButtonText(q, result) {
    if (session.isExam) return session.index === session.ids.length - 1 ? '交卷' : '保存并下一题';
    if (!result) return q.type === 'short' ? '查看参考答案' : '提交答案';
    if (session.index === session.ids.length - 1) return '完成练习';
    return '下一题';
  }

  function hasAnswer(v) {
    return Array.isArray(v) ? v.length > 0 : String(v ?? '').trim().length > 0;
  }

  function syncTextAnswer() {
    if (!session) return;
    const q = currentQuestion();
    const input = document.getElementById('textAnswer');
    if (q && input) {
      session.answers[q.id] = input.value;
      saveSession();
    }
  }

  function normalizeText(s) {
    return String(s ?? '')
      .trim()
      .toLowerCase()
      .replace(/[\s　]+/g, '')
      .replace(/[，,。；;：:、]/g, '');
  }

  function splitAnswerParts(s) {
    return String(s ?? '').split(/[，,、；;]+/).map(x => x.trim()).filter(Boolean);
  }

  function fillCorrect(q, userValue) {
    const expected = splitAnswerParts(q.answer);
    const actual = splitAnswerParts(userValue);
    if (!expected.length || !actual.length || expected.length !== actual.length) return false;

    const expectedGroups = expected.map(part => part.split('|||').map(normalizeText));
    const actualNorm = actual.map(normalizeText);
    const isUnordered = String(q.fillType || '').includes('无序');

    if (!isUnordered) {
      return expectedGroups.every((syns, i) => syns.includes(actualNorm[i]));
    }

    const remaining = [...actualNorm];
    return expectedGroups.every(syns => {
      const idx = remaining.findIndex(v => syns.includes(v));
      if (idx < 0) return false;
      remaining.splice(idx, 1);
      return true;
    });
  }

  function checkAnswer(q, userValue) {
    if (q.type === 'single' || q.type === 'judge') return String(userValue || '') === String(q.answer || '');
    if (q.type === 'multiple') {
      const a = [...new Set(String(userValue || '').split(''))].sort().join('');
      const b = [...new Set(String(q.answer || '').split(''))].sort().join('');
      return a === b;
    }
    if (q.type === 'fill') return fillCorrect(q, userValue);
    return null;
  }

  function submitPracticeCurrent() {
    syncTextAnswer();
    const q = currentQuestion();
    const answer = session.answers[q.id];
    if (session.results[q.id]) {
      if (session.index < session.ids.length - 1) moveTo(session.index + 1);
      else finishPractice();
      return;
    }
    if (!hasAnswer(answer)) { showToast('请先作答'); return; }

    if (q.type === 'short') {
      session.results[q.id] = 'revealed';
      markPracticed(q.id, null);
      saveSession();
      renderQuiz();
      return;
    }

    const ok = checkAnswer(q, answer);
    session.results[q.id] = ok;
    markPracticed(q.id, ok);
    saveSession();
    renderQuiz();

    if (ok && state.settings.autoNext && session.index < session.ids.length - 1) {
      setTimeout(() => {
        if (location.hash.startsWith('#quiz') && session?.results?.[q.id] === true) moveTo(session.index + 1);
      }, 600);
    }
  }

  function markPracticed(id, correct) {
    const old = state.practiced[id] || { count: 0 };
    state.practiced[id] = { count: (old.count || 0) + 1, lastCorrect: correct, time: Date.now() };
    if (correct === false) addUnique(state.wrongIds, id);
    if (correct === true) removeValue(state.wrongIds, id);
    saveState();
  }

  function addUnique(arr, value) {
    if (!arr.includes(value)) arr.push(value);
  }

  function removeValue(arr, value) {
    const idx = arr.indexOf(value);
    if (idx >= 0) arr.splice(idx, 1);
  }

  function rateShort(good) {
    const q = currentQuestion();
    const result = good ? 'self-correct' : 'self-wrong';
    session.results[q.id] = result;
    markPracticed(q.id, good);
    saveSession();
    renderQuiz();
  }

  function finishPractice() {
    const judged = Object.values(session.results).filter(v => v === true || v === false || v === 'self-correct' || v === 'self-wrong');
    const correct = judged.filter(v => v === true || v === 'self-correct').length;
    const total = judged.length;
    showToast(total ? `本次完成：${correct}/${total} 题掌握` : '练习已完成', 1800);
    session = null;
    saveSession();
    setTimeout(() => routeTo('#home'), 350);
  }

  function moveTo(index) {
    syncTextAnswer();
    if (!session) return;
    session.index = Math.max(0, Math.min(session.ids.length - 1, index));
    saveSession();
    renderQuiz();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function selectOption(key) {
    const q = currentQuestion();
    if (!q) return;
    if (!session.isExam && session.results[q.id]) return;

    if (q.type === 'multiple') {
      const set = new Set(String(session.answers[q.id] || '').split('').filter(Boolean));
      set.has(key) ? set.delete(key) : set.add(key);
      session.answers[q.id] = [...set].sort().join('');
    } else {
      session.answers[q.id] = key;
    }
    saveSession();
    renderQuiz();
  }

  function toggleFavorite() {
    const q = currentQuestion();
    if (!q) return;
    if (state.favoriteIds.includes(q.id)) {
      removeValue(state.favoriteIds, q.id); showToast('已取消收藏');
    } else {
      addUnique(state.favoriteIds, q.id); showToast('已加入收藏');
    }
    saveState();
    renderQuiz();
  }

  function showNavigator() {
    if (!session) return;
    const items = session.ids.map((id, i) => {
      const r = session.results[id];
      const answered = hasAnswer(session.answers[id]);
      let cls = '';
      if (!session.isExam && (r === true || r === 'self-correct')) cls = 'correct';
      else if (!session.isExam && (r === false || r === 'self-wrong')) cls = 'wrong';
      else if (answered) cls = 'answered';
      if (i === session.index) cls += ' current';
      return `<button class="num-btn ${cls}" data-jump="${i}">${i + 1}</button>`;
    }).join('');

    const el = document.createElement('div');
    el.className = 'sheet-backdrop';
    el.id = 'navSheet';
    el.innerHTML = `<div class="sheet" role="dialog" aria-modal="true">
      <div class="sheet-handle"></div>
      <div class="sheet-title">答题卡</div>
      <div class="sheet-subtitle">点击题号快速跳转 · 当前第 ${session.index + 1} 题</div>
      <div class="number-grid">${items}</div>
      ${session.isExam ? '<button class="primary-btn sheet-close" data-action="submit-exam">交卷并查看成绩</button>' : '<button class="secondary-btn sheet-close" data-action="close-sheet">关闭</button>'}
    </div>`;
    document.body.appendChild(el);
  }

  function closeSheet() {
    document.getElementById('navSheet')?.remove();
  }

  function getRemainingSec() {
    if (!session?.isExam) return 0;
    const elapsed = Math.floor((Date.now() - session.startedAt) / 1000);
    return Math.max(0, (session.durationSec || 3600) - elapsed);
  }

  function formatRemaining(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }

  function formatDuration(sec) {
    const m = Math.floor(Number(sec || 0) / 60);
    const s = Math.floor(Number(sec || 0) % 60);
    return `${m}分${String(s).padStart(2,'0')}秒`;
  }

  function startTimer() {
    stopTimer();
    const tick = () => {
      const remaining = getRemainingSec();
      const node = document.getElementById('examTimer');
      if (node) node.textContent = formatRemaining(remaining);
      if (remaining <= 0 && session?.isExam && !session.submitted) {
        submitExam(true);
      }
    };
    tick();
    timerHandle = setInterval(tick, 1000);
  }

  function stopTimer() {
    if (timerHandle) clearInterval(timerHandle);
    timerHandle = null;
  }

  function handleExamMain() {
    syncTextAnswer();
    if (session.index === session.ids.length - 1) {
      submitExam(false);
    } else {
      moveTo(session.index + 1);
    }
  }

  function submitExam(auto = false) {
    if (!session?.isExam || session.submitted) return;
    syncTextAnswer();
    closeSheet();
    const unanswered = session.ids.filter(id => !hasAnswer(session.answers[id])).length;
    if (!auto && unanswered > 0) {
      const ok = window.confirm(`还有 ${unanswered} 题未作答，确定现在交卷吗？`);
      if (!ok) return;
    }

    let correct = 0;
    const wrongIds = [];
    for (const id of session.ids) {
      const q = qById(id);
      const ok = checkAnswer(q, session.answers[id]);
      session.results[id] = ok;
      if (ok) correct++; else wrongIds.push(id);
      markPracticed(id, ok);
    }
    const total = session.ids.length;
    const score = Math.round(correct / total * 100);
    const duration = Math.min(session.durationSec || 3600, Math.floor((Date.now() - session.startedAt) / 1000));
    const record = {
      id: Date.now(), score, correct, total, duration,
      date: new Date().toLocaleString('zh-CN', { hour12: false }), wrongIds
    };
    state.records.push(record);
    if (state.records.length > 50) state.records = state.records.slice(-50);
    saveState();

    session.submitted = true;
    session.examResult = record;
    saveSession();
    stopTimer();
    renderExamResult();
    if (auto) showToast('考试时间到，已自动交卷', 2200);
  }

  function renderExamResult() {
    stopTimer();
    const r = session?.examResult;
    if (!r) { routeTo('#home'); return; }
    const angle = Math.max(0, Math.min(360, r.score / 100 * 360));
    let title = '继续加油';
    if (r.score >= 90) title = '成绩优秀';
    else if (r.score >= 80) title = '掌握良好';
    else if (r.score >= 60) title = '考试通过';
    APP.innerHTML = `
      <main class="page">
        ${topbar('考试结果')}
        <div class="container">
          <section class="exam-result">
            <div class="score-ring" style="--score-angle:${angle}deg"><div class="score-inner"><div class="score-value">${r.score}</div><div class="score-unit">满分 100</div></div></div>
            <div class="result-title">${title}</div>
            <div class="result-sub">本次模拟考试已保存到考试记录</div>
            <div class="result-stats">
              <div class="result-stat"><strong>${r.correct}</strong><span>答对</span></div>
              <div class="result-stat"><strong>${r.total - r.correct}</strong><span>答错</span></div>
              <div class="result-stat"><strong>${formatDuration(r.duration)}</strong><span>用时</span></div>
            </div>
            <div class="result-actions">
              ${r.wrongIds?.length ? '<button class="primary-btn" data-action="review-exam-wrong">练习本次错题</button>' : ''}
              <button class="secondary-btn" data-action="new-exam">再考一次</button>
              <button class="secondary-btn" data-action="go-home">返回首页</button>
            </div>
          </section>
        </div>
      </main>`;
  }

  function renderCollection(mode) {
    stopTimer();
    const isWrong = mode === 'wrong';
    const ids = isWrong ? state.wrongIds : state.favoriteIds;
    const title = isWrong ? '错题本' : '收藏夹';
    APP.innerHTML = `
      <main class="page">
        ${topbar(title)}
        <div class="container list-page">
          ${ids.length ? `
            <div class="list-card">
              ${ids.map((id, idx) => {
                const q = qById(id); if (!q) return '';
                return `<button class="list-item" data-collection-start="${idx}">
                  <div class="list-icon">${TYPE_INFO[q.type]?.icon || '📘'}</div>
                  <div class="list-main"><div class="list-title">${esc(trimText(q.question, 34))}</div><div class="list-meta">${esc(q.typeName)} · 题库编号 ${q.id}</div></div>
                  <div class="list-arrow">›</div>
                </button>`;
              }).join('')}
            </div>
            <button class="primary-btn mt-18" style="width:100%" data-action="start-collection">从第一题开始练习</button>
          ` : emptyState(isWrong ? '🎉' : '⭐', isWrong ? '暂时没有错题' : '暂时没有收藏', isWrong ? '答错的题目会自动加入这里，之后答对会自动移除。' : '在答题页面点击右上角星标即可收藏题目。', '返回首页', 'go-home')}
        </div>
      </main>`;
  }

  function trimText(s, max) {
    s = String(s || '');
    return s.length > max ? s.slice(0, max) + '…' : s;
  }

  function renderRoute() {
    const { path } = parseRoute();
    closeSheet();
    if (path === 'home') renderHome();
    else if (path === 'special') renderSpecial();
    else if (path === 'records') renderRecords();
    else if (path === 'settings') renderSettings();
    else if (path === 'wrong') renderCollection('wrong');
    else if (path === 'favorite') renderCollection('favorite');
    else if (path === 'quiz') renderQuiz();
    else renderHome();
  }

  document.addEventListener('click', e => {
    const home = e.target.closest('[data-home-action]');
    if (home) {
      const a = home.dataset.homeAction;
      if (a === 'sequence') startPractice('sequence');
      else if (a === 'random') startPractice('random');
      else if (a === 'special') routeTo('#special');
      else if (a === 'exam') startExam();
      else if (a === 'wrong') routeTo('#wrong');
      else if (a === 'favorite') routeTo('#favorite');
      else if (a === 'records') routeTo('#records');
      else if (a === 'settings') routeTo('#settings');
      return;
    }

    const typeBtn = e.target.closest('[data-type]');
    if (typeBtn) { startPractice('type', { type: typeBtn.dataset.type }); return; }

    const option = e.target.closest('[data-option]');
    if (option) { selectOption(option.dataset.option); return; }

    const jump = e.target.closest('[data-jump]');
    if (jump) { closeSheet(); moveTo(Number(jump.dataset.jump)); return; }

    const collection = e.target.closest('[data-collection-start]');
    if (collection) {
      const mode = parseRoute().path;
      const ids = mode === 'wrong' ? state.wrongIds : state.favoriteIds;
      const start = Number(collection.dataset.collectionStart || 0);
      const ordered = [...ids.slice(start), ...ids.slice(0, start)];
      startPractice('custom', { ids: ordered, title: mode === 'wrong' ? '错题本' : '收藏夹' });
      return;
    }

    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;

    if (action === 'back') {
      if (location.hash === '#quiz' && session?.isExam && !session.submitted) {
        const ok = window.confirm('考试正在进行，返回后仍可继续本次考试。确定返回吗？');
        if (!ok) return;
      }
      history.length > 1 ? history.back() : routeTo('#home');
    } else if (action === 'navigator') showNavigator();
    else if (action === 'close-sheet') closeSheet();
    else if (action === 'favorite') toggleFavorite();
    else if (action === 'prev') moveTo(session.index - 1);
    else if (action === 'next') moveTo(session.index + 1);
    else if (action === 'main') session.isExam ? handleExamMain() : submitPracticeCurrent();
    else if (action === 'self-rate') rateShort(btn.dataset.rate === 'good');
    else if (action === 'submit-exam') submitExam(false);
    else if (action === 'start-exam' || action === 'new-exam') startExam();
    else if (action === 'go-home') { session = null; saveSession(); routeTo('#home'); }
    else if (action === 'review-exam-wrong') {
      const ids = session?.examResult?.wrongIds || [];
      session = null; saveSession();
      startPractice('custom', { ids, title: '本次考试错题' });
    } else if (action === 'start-collection') {
      const mode = parseRoute().path;
      startPractice(mode === 'wrong' ? 'wrong' : 'favorite');
    } else if (action === 'toggle-auto') {
      state.settings.autoNext = !state.settings.autoNext; saveState(); renderSettings();
    } else if (action === 'clear-records') {
      if (window.confirm('确定清空全部考试记录吗？')) { state.records = []; saveState(); renderRecords(); }
    } else if (action === 'reset-data') {
      if (window.confirm('确定清空练习进度、错题、收藏和考试记录吗？此操作不可恢复。')) {
        state = defaultState(); saveState(); session = null; saveSession(); renderSettings(); showToast('学习数据已清空');
      }
    }
  });

  document.addEventListener('input', e => {
    if (e.target?.id === 'textAnswer' && session) {
      const q = currentQuestion();
      if (q) { session.answers[q.id] = e.target.value; saveSession(); }
    }
  });

  document.addEventListener('click', e => {
    const backdrop = e.target.closest('.sheet-backdrop');
    if (backdrop && e.target === backdrop) closeSheet();
  });

  window.addEventListener('hashchange', renderRoute);
  window.addEventListener('beforeunload', () => { syncTextAnswer(); saveSession(); });

  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
  }

  if (!BANK.length) {
    APP.innerHTML = `<div class="container" style="padding-top:60px"><div class="list-card empty-state"><div class="empty-icon">⚠️</div><div class="empty-title">题库加载失败</div><div class="empty-desc">请确认 data/questions.js 文件存在且可访问。</div></div></div>`;
  } else {
    if (!location.hash) history.replaceState(null, '', '#home');
    renderRoute();
  }
})();
