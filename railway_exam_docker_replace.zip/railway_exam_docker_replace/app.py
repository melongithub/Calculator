import os
from pathlib import Path

from flask import Flask, abort, send_from_directory

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = (BASE_DIR / "web").resolve()

app = Flask(__name__, static_folder=None)


@app.get("/")
def index():
    return send_from_directory(WEB_DIR, "index.html")


@app.get("/<path:requested_path>")
def web_files(requested_path: str):
    """Serve H5 assets from /web and fall back to index.html for client routes."""
    candidate = (WEB_DIR / requested_path).resolve()

    # Prevent path traversal outside WEB_DIR.
    if candidate != WEB_DIR and WEB_DIR not in candidate.parents:
        abort(404)

    if candidate.is_file():
        return send_from_directory(WEB_DIR, requested_path)

    return send_from_directory(WEB_DIR, "index.html")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
