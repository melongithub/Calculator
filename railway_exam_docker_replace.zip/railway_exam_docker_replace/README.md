# 铁路线路工考试 H5（Docker 版）

此包用于直接替换原 Flask/Docker 项目。

## 启动

```bash
docker compose up -d --build
```

手机访问：

```text
http://电视盒子IP:8080/
```

## 更新

替换文件后执行：

```bash
docker compose down
docker compose up -d --build
```

题库与前端文件都位于 `web/` 目录。
